export type DepartmentId = 'general' | 'children' | 'women' | 'bones' | 'ent' | 'eyes' | 'skin' | 'lab' | 'pharmacy';

export interface Department {
  id: DepartmentId;
  nameKey: string;
  hintKey: string;
  roomKey: string;
  floor: number;
  doctor: string;
  serviceMinutes: number;
  opdHours: string;
  seats: number;
  prefix: string;
}

export const DEPARTMENTS: Department[] = [
  { id: 'general', nameKey: 'deptGeneral', hintKey: 'hintGeneral', roomKey: 'room1', floor: 1, doctor: 'Dr. Meera Rao', serviceMinutes: 6, opdHours: '09:00–14:00', seats: 12, prefix: 'A' },
  { id: 'children', nameKey: 'deptChildren', hintKey: 'hintChildren', roomKey: 'room3', floor: 1, doctor: 'Dr. Kabir Sen', serviceMinutes: 8, opdHours: '09:00–14:00', seats: 12, prefix: 'C' },
  { id: 'women', nameKey: 'deptWomen', hintKey: 'hintWomen', roomKey: 'room4', floor: 1, doctor: 'Dr. Nila Thomas', serviceMinutes: 9, opdHours: '09:00–14:00', seats: 12, prefix: 'W' },
  { id: 'bones', nameKey: 'deptBones', hintKey: 'hintBones', roomKey: 'room5', floor: 1, doctor: 'Dr. Arjun Das', serviceMinutes: 8, opdHours: '09:00–14:00', seats: 12, prefix: 'B' },
  { id: 'ent', nameKey: 'deptEnt', hintKey: 'hintEnt', roomKey: 'room6', floor: 1, doctor: 'Dr. Leela Shah', serviceMinutes: 7, opdHours: '09:00–14:00', seats: 12, prefix: 'E' },
  { id: 'eyes', nameKey: 'deptEyes', hintKey: 'hintEyes', roomKey: 'room7', floor: 1, doctor: 'Dr. Ravi Iyer', serviceMinutes: 7, opdHours: '09:00–14:00', seats: 12, prefix: 'Y' },
  { id: 'skin', nameKey: 'deptSkin', hintKey: 'hintSkin', roomKey: 'room8', floor: 1, doctor: 'Dr. Tara Bose', serviceMinutes: 6, opdHours: '09:00–14:00', seats: 12, prefix: 'S' },
  { id: 'lab', nameKey: 'deptLab', hintKey: 'hintLab', roomKey: 'lab', floor: 0, doctor: 'Sample Lab Desk', serviceMinutes: 4, opdHours: '09:00–14:00', seats: 12, prefix: 'L' },
  { id: 'pharmacy', nameKey: 'deptPharmacy', hintKey: 'hintPharmacy', roomKey: 'pharmacy', floor: 0, doctor: 'Sample Pharmacy Desk', serviceMinutes: 3, opdHours: '09:00–14:00', seats: 12, prefix: 'P' },
];

export const getDepartment = (id: DepartmentId) => DEPARTMENTS.find((d) => d.id === id) ?? DEPARTMENTS[0];
