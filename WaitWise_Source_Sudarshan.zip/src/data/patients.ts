import type { DepartmentId } from './departments';
import type { QueueEntry } from '../state/queueMachine';

export function makeSeedPatients(now = Date.now()): QueueEntry[] {
  const seed: Array<[string, DepartmentId, string, number]> = [
    ['A-109', 'general', 'Demo guest 1', 4],
    ['A-110', 'general', 'Demo guest 2', 3],
    ['A-111', 'general', 'Demo guest 3', 2],
    ['A-112', 'general', 'Kamla demo', 1],
    ['C-101', 'children', 'Demo guest 4', 4],
    ['C-102', 'children', 'Demo guest 5', 2],
    ['W-101', 'women', 'Demo guest 6', 4],
    ['B-101', 'bones', 'Demo guest 7', 3],
    ['E-101', 'ent', 'Demo guest 8', 3],
    ['Y-101', 'eyes', 'Demo guest 9', 2],
    ['S-101', 'skin', 'Demo guest 10', 2],
    ['L-101', 'lab', 'Demo guest 11', 3],
    ['L-102', 'lab', 'Demo guest 12', 1],
    ['P-101', 'pharmacy', 'Demo guest 13', 2],
  ];
  return seed.map(([token, department, alias, offset]) => ({
    id: `seed-${token}`,
    token,
    department,
    alias,
    status: 'waiting',
    createdAt: new Date(now - offset * 60_000).toISOString(),
    updatedAt: new Date(now - offset * 20_000).toISOString(),
    synthetic: true,
  }));
}
