export type PlaceId = string;
export interface Place { id: PlaceId; labelKey: string; floor: number; x: number; y: number; landmarkKey: string; }
export interface RouteEdge { from: PlaceId; to: PlaceId; metres: number; stairs: boolean; }

export const PLACES: Place[] = [
  { id: 'entrance', labelKey: 'placeEntrance', floor: 0, x: 54, y: 62, landmarkKey: 'landmarkEntrance' },
  { id: 'registration', labelKey: 'placeRegistration', floor: 0, x: 150, y: 62, landmarkKey: 'landmarkRegistration' },
  { id: 'help', labelKey: 'placeHelp', floor: 0, x: 245, y: 62, landmarkKey: 'landmarkHelp' },
  { id: 'emergency', labelKey: 'placeEmergency', floor: 0, x: 440, y: 62, landmarkKey: 'landmarkEmergency' },
  { id: 'pharmacy', labelKey: 'placePharmacy', floor: 0, x: 350, y: 62, landmarkKey: 'landmarkPharmacy' },
  { id: 'lab', labelKey: 'placeLab', floor: 0, x: 150, y: 105, landmarkKey: 'landmarkLab' },
  { id: 'xray', labelKey: 'placeXray', floor: 0, x: 54, y: 105, landmarkKey: 'landmarkXray' },
  { id: 'water', labelKey: 'placeWater', floor: 0, x: 54, y: 148, landmarkKey: 'landmarkWater' },
  { id: 'toilets0', labelKey: 'placeToilets', floor: 0, x: 350, y: 105, landmarkKey: 'landmarkToilets' },
  { id: 'wheelchair', labelKey: 'placeWheelchair', floor: 0, x: 245, y: 105, landmarkKey: 'landmarkWheelchair' },
  { id: 'lift0', labelKey: 'placeLift', floor: 0, x: 245, y: 148, landmarkKey: 'landmarkLift' },
  { id: 'ramp', labelKey: 'placeRamp', floor: 0, x: 150, y: 148, landmarkKey: 'landmarkRamp' },
  { id: 'stairs0', labelKey: 'placeStairs', floor: 0, x: 440, y: 105, landmarkKey: 'landmarkStairs' },
  { id: 'waiting1', labelKey: 'placeWaitingHall', floor: 1, x: 245, y: 178, landmarkKey: 'landmarkWaitingHall' },
  { id: 'lift1', labelKey: 'placeLift', floor: 1, x: 245, y: 210, landmarkKey: 'landmarkLift' },
  { id: 'room1', labelKey: 'room1', floor: 1, x: 54, y: 178, landmarkKey: 'landmarkRoom1' },
  { id: 'room2', labelKey: 'room2', floor: 1, x: 110, y: 178, landmarkKey: 'landmarkRoom2' },
  { id: 'room3', labelKey: 'room3', floor: 1, x: 165, y: 178, landmarkKey: 'landmarkRoom3' },
  { id: 'room4', labelKey: 'room4', floor: 1, x: 325, y: 178, landmarkKey: 'landmarkRoom4' },
  { id: 'room5', labelKey: 'room5', floor: 1, x: 380, y: 178, landmarkKey: 'landmarkRoom5' },
  { id: 'room6', labelKey: 'room6', floor: 1, x: 435, y: 178, landmarkKey: 'landmarkRoom6' },
  { id: 'room7', labelKey: 'room7', floor: 1, x: 325, y: 210, landmarkKey: 'landmarkRoom7' },
  { id: 'room8', labelKey: 'room8', floor: 1, x: 380, y: 210, landmarkKey: 'landmarkRoom8' },
  { id: 'toilets1', labelKey: 'placeToilets', floor: 1, x: 435, y: 210, landmarkKey: 'landmarkToilets' },
  { id: 'stairs1', labelKey: 'placeStairs', floor: 1, x: 440, y: 240, landmarkKey: 'landmarkStairs' },
  { id: 'lift2', labelKey: 'placeLift', floor: 2, x: 245, y: 272, landmarkKey: 'landmarkLift' },
  { id: 'ward4', labelKey: 'placeWard4', floor: 2, x: 110, y: 272, landmarkKey: 'landmarkWard' },
  { id: 'ward5', labelKey: 'placeWard5', floor: 2, x: 325, y: 272, landmarkKey: 'landmarkWard' },
  { id: 'ward6', labelKey: 'placeWard6', floor: 2, x: 380, y: 272, landmarkKey: 'landmarkWard' },
  { id: 'nurse', labelKey: 'placeNurses', floor: 2, x: 165, y: 272, landmarkKey: 'landmarkWard' },
  { id: 'toilets2', labelKey: 'placeToilets', floor: 2, x: 435, y: 272, landmarkKey: 'landmarkToilets' },
  { id: 'stairs2', labelKey: 'placeStairs', floor: 2, x: 440, y: 294, landmarkKey: 'landmarkStairs' },
];

const edgeRows: Array<[string, string, number, boolean?]> = [
  ['entrance','registration',18],['registration','help',14],['help','emergency',20],['help','pharmacy',16],['registration','lab',12],['registration','xray',16],['entrance','water',8],['entrance','toilets0',25],['entrance','wheelchair',7],['wheelchair','lift0',10],['help','lift0',8],['registration','ramp',12],['ramp','lift0',18],['pharmacy','toilets0',9],['pharmacy','stairs0',7],
  ['lift0','lift1',0],['lift1','lift2',0],['lift1','waiting1',5],['waiting1','room1',10],['waiting1','room2',10],['waiting1','room3',8],['waiting1','room4',11],['waiting1','room5',13],['waiting1','room6',15],['waiting1','room7',12],['waiting1','room8',14],['waiting1','toilets1',16],
  ['lift2','ward4',10],['lift2','ward5',10],['lift2','ward6',12],['lift2','nurse',8],['lift2','toilets2',14],
  ['stairs0','stairs1',12,true],['stairs1','stairs2',15,true],['lift0','stairs0',24],
];
export const EDGES: RouteEdge[] = edgeRows.flatMap(([from,to,metres,stairs]) => [{from,to,metres,stairs:stairs===true},{from:to,to:from,metres,stairs:stairs===true}]);

export interface RouteResult { nodes: PlaceId[]; metres: number; stairEdges: number; }
export function shortestPath(origin: PlaceId, destination: PlaceId, avoidStairs = true): RouteResult | null {
  if (!PLACES.some(p=>p.id===origin) || !PLACES.some(p=>p.id===destination)) return null;
  const distances = new Map<string, number>(PLACES.map(p=>[p.id,Infinity]));
  const previous = new Map<string,string>(); const pending = new Set(PLACES.map(p=>p.id)); distances.set(origin,0);
  while(pending.size){
    let current: string | undefined; let best=Infinity;
    for(const id of pending){const d=distances.get(id)!;if(d<best){best=d;current=id;}}
    if(!current||best===Infinity)break; pending.delete(current); if(current===destination)break;
    for(const edge of EDGES){if(edge.from!==current||(avoidStairs&&edge.stairs)||!pending.has(edge.to))continue;const next=best+edge.metres;if(next<distances.get(edge.to)!){distances.set(edge.to,next);previous.set(edge.to,current);}}
  }
  if(distances.get(destination)===Infinity)return null;
  const nodes=[destination];let node=destination;while(node!==origin){const parent=previous.get(node);if(!parent)return null;nodes.unshift(parent);node=parent;}
  const stairEdges=nodes.slice(1).reduce((n,id,i)=>n+(EDGES.some(e=>e.from===nodes[i]&&e.to===id&&e.stairs)?1:0),0);
  return {nodes,metres:distances.get(destination)!,stairEdges};
}
