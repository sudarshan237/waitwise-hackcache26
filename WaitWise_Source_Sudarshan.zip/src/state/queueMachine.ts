import type { DepartmentId } from '../data/departments';

export type QueueStatus = 'waiting' | 'called' | 'with_staff' | 'completed' | 'on_hold' | 'no_show';
export interface QueueEntry {
  id: string;
  token: string;
  department: DepartmentId;
  alias: string;
  status: QueueStatus;
  createdAt: string;
  updatedAt: string;
  synthetic: boolean;
  startedAt?: string;
  serviceMinutes?: number;
}

export const ALLOWED_TRANSITIONS: Record<string, { from: QueueStatus[]; to: QueueStatus }> = {
  call: { from: ['waiting'], to: 'called' },
  start: { from: ['called'], to: 'with_staff' },
  complete: { from: ['with_staff'], to: 'completed' },
  hold: { from: ['waiting'], to: 'on_hold' },
  return: { from: ['on_hold'], to: 'waiting' },
  noShow: { from: ['called'], to: 'no_show' },
  requeue: { from: ['no_show'], to: 'waiting' },
};

export type QueueAction = keyof typeof ALLOWED_TRANSITIONS;

export function transitionEntry(entry: QueueEntry | undefined, action: QueueAction, updatedAt = new Date().toISOString()): QueueEntry {
  if (!entry) throw new Error('Token not found. Refresh the simulated queue and try again.');
  const rule = ALLOWED_TRANSITIONS[action];
  if (!rule.from.includes(entry.status)) {
    throw new Error(`Cannot ${action} a token while it is ${entry.status}.`);
  }
  return { ...entry, status: rule.to, updatedAt };
}

export function countAhead(entry: QueueEntry, queue: QueueEntry[]): number {
  if (entry.status !== 'waiting') return 0;
  const stamp = new Date(entry.createdAt).getTime();
  return queue.filter((other) => other.department === entry.department && other.status === 'waiting' && other.id !== entry.id &&
    (new Date(other.createdAt).getTime() < stamp || (new Date(other.createdAt).getTime() === stamp && other.token.localeCompare(entry.token) < 0))).length;
}
