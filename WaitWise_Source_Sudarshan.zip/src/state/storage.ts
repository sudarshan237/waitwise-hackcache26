import { makeSeedPatients } from '../data/patients';
import type { DepartmentId } from '../data/departments';
import type { QueueEntry } from './queueMachine';
import type { DoctorState } from '../utils/waitTime';

export interface UrgentFlag { id: string; token: string; createdAt: string; seen: boolean; source: string; }
export interface AppState {
  queue: QueueEntry[];
  flags: UrgentFlag[];
  doctors: Partial<Record<DepartmentId, DoctorState>>;
  selectedToken: string;
  nextNumbers: Partial<Record<DepartmentId, number>>;
}
export const STORAGE_KEY = 'waitwise-hackcache26-state-v1';

export function initialState(): AppState {
  return {
    queue: makeSeedPatients(), flags: [], selectedToken: 'A-112',
    doctors: {},
    nextNumbers: { general: 113, children: 103, women: 102, bones: 102, ent: 102, eyes: 102, skin: 102, lab: 103, pharmacy: 102 },
  };
}

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return initialState();
    const value = JSON.parse(raw) as Partial<AppState>;
    if (!Array.isArray(value.queue) || !Array.isArray(value.flags) || typeof value.selectedToken !== 'string') return initialState();
    return { ...initialState(), ...value };
  } catch {
    return initialState();
  }
}

export function saveState(state: AppState): void {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch { /* Browser state still works in memory when storage is blocked. */ }
}
