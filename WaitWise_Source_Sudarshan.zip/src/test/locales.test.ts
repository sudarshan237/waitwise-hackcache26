import { describe, expect, it } from 'vitest';
import { locales, localeOptions } from '../locales';

describe('locale coverage',()=>{
  it('keeps every required interface key in all four languages',()=>{
    const keys=Object.keys(locales.en).sort();
    for(const locale of ['hi','ta','kn'] as const) expect(Object.keys(locales[locale]).sort(),`${locale} has complete translations`).toEqual(keys);
  });
  it('shows each language name in its own script',()=>{
    expect(localeOptions.map(x=>x.value)).toEqual(['en','hi','ta','kn']);
    expect(localeOptions.map(x=>x.label)).toContain('தமிழ்');
    expect(localeOptions.map(x=>x.label)).toContain('ಕನ್ನಡ');
  });
  it('contains clear emergency and no-token guidance in every locale',()=>{
    for(const locale of Object.values(locales)){
      expect(locale.noToken.trim()).not.toBe(''); expect(locale.call112).toContain('112'); expect(locale.call108).toContain('108');
    }
  });
});
