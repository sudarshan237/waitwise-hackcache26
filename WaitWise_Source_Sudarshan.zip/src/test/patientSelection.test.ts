import { describe, expect, it } from 'vitest';
import { selectTokenForRoute, tokenForUrgentRequest } from '../utils/patientSelection';
import { makeSeedPatients } from '../data/patients';

describe('patient token route selection', () => {
  const queue = makeSeedPatients();
  it('shows lookup instead of restoring a prior token when URL has no token', () => {
    expect(selectTokenForRoute(null, queue)).toBeUndefined();
    expect(selectTokenForRoute('   ', queue)).toBeUndefined();
  });
  it('selects only the token explicitly in the route', () => {
    expect(selectTokenForRoute('a-112', queue)?.token).toBe('A-112');
    expect(selectTokenForRoute('A-113', queue)).toBeUndefined();
    expect(selectTokenForRoute('unknown', queue)).toBeUndefined();
  });
  it('never attaches an old selected token to a global urgent request', () => {
    expect(tokenForUrgentRequest('/patient', '', queue)).toBe('NO-TOKEN');
    expect(tokenForUrgentRequest('/', '?token=A-112', queue)).toBe('NO-TOKEN');
    expect(tokenForUrgentRequest('/patient', '?token=a-112', queue)).toBe('A-112');
    expect(tokenForUrgentRequest('/patient', '?token=missing', queue)).toBe('NO-TOKEN');
  });
});
