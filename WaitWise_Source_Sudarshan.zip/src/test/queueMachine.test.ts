import { describe, expect, it } from 'vitest';
import { transitionEntry, countAhead, type QueueEntry } from '../state/queueMachine';

const make = (id:string,status:QueueEntry['status']='waiting',minute=0):QueueEntry => ({id,token:`A-${id}`,department:'general',alias:`Demo ${id}`,status,createdAt:new Date(Date.UTC(2026,0,1,0,minute)).toISOString(),updatedAt:new Date().toISOString(),synthetic:true});

describe('queue state machine',()=>{
  it('allows valid transitions in the service lifecycle',()=>{
    let entry=make('1');
    entry=transitionEntry(entry,'call'); expect(entry.status).toBe('called');
    entry=transitionEntry(entry,'start'); expect(entry.status).toBe('with_staff');
    entry=transitionEntry(entry,'complete'); expect(entry.status).toBe('completed');
  });
  it('allows hold, return, no-show and requeue paths',()=>{
    expect(transitionEntry(transitionEntry(make('2'),'hold'),'return').status).toBe('waiting');
    expect(transitionEntry(transitionEntry(make('3'),'call'),'noShow').status).toBe('no_show');
    expect(transitionEntry(transitionEntry(transitionEntry(make('4'),'call'),'noShow'),'requeue').status).toBe('waiting');
  });
  it('rejects illegal transitions and missing entries',()=>{
    expect(()=>transitionEntry(make('5'),'complete')).toThrow(/Cannot complete/);
    expect(()=>transitionEntry(make('6','completed'),'call')).toThrow(/Cannot call/);
    expect(()=>transitionEntry(undefined,'call')).toThrow(/Token not found/);
  });
  it('counts only earlier waiting tokens from the same department',()=>{
    const target=make('4','waiting',4);
    const queue=[make('1','waiting',1),make('2','waiting',2),make('3','called',3),make('5','waiting',0)];
    expect(countAhead(target,queue)).toBe(2);
    expect(countAhead(make('8','called',8),queue)).toBe(0);
  });
});
