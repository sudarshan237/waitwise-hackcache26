import { describe, expect, it } from 'vitest';
import { PLACES, shortestPath, EDGES } from '../routing/dijkstra';

describe('hospital wayfinding graph',()=>{
  it('finds routes among every supported non-stair location with stairs avoided',()=>{
    const places=PLACES.filter(p=>!p.id.startsWith('stairs'));
    for(const origin of places) for(const destination of places){
      const route=shortestPath(origin.id,destination.id,true);
      expect(route,`${origin.id} -> ${destination.id}`).not.toBeNull();
      expect(route!.stairEdges,`${origin.id} -> ${destination.id}`).toBe(0);
      expect(route!.nodes[0]).toBe(origin.id); expect(route!.nodes.at(-1)).toBe(destination.id);
    }
  });
  it('returns null for unknown locations',()=>{
    expect(shortestPath('not-a-place','entrance')).toBeNull();
    expect(shortestPath('entrance','not-a-place')).toBeNull();
  });
  it('uses symmetric distances and non-negative graph edges',()=>{
    expect(EDGES.every(e=>e.metres>=0)).toBe(true);
    for(const edge of EDGES) expect(EDGES.some(reverse=>reverse.from===edge.to&&reverse.to===edge.from&&reverse.metres===edge.metres)).toBe(true);
  });
});
