import { describe, expect, it } from 'vitest';
import { allocateToken } from '../utils/tokens';

describe('collision-safe token allocation', () => {
  it('does not reuse a previously registered token when the counter is stale', () => {
    const first = allocateToken('A', 113, ['A-112']);
    expect(first).toEqual({ token: 'A-113', nextNumber: 114 });
    const second = allocateToken('A', 113, ['A-112', first.token]);
    expect(second).toEqual({ token: 'A-114', nextNumber: 115 });
  });
  it('normalizes tokens case-insensitively and uses safe defaults', () => {
    expect(allocateToken('a', undefined, ['A-101']).token).toBe('A-102');
  });
});
