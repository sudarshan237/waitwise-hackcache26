import { describe, expect, it } from 'vitest';
import { estimateWaitMinutes, averageServiceMinutes } from '../utils/waitTime';
import type { QueueEntry } from '../state/queueMachine';

const completed=(id:string,minutes:number,stamp:string):QueueEntry=>({id,token:`A-${id}`,department:'general',alias:'Sample',status:'completed',createdAt:stamp,updatedAt:stamp,synthetic:true,serviceMinutes:minutes});

describe('simulated wait estimates',()=>{
  it('multiplies people ahead by service time, adds delay, rounds up to 5',()=>{
    expect(estimateWaitMinutes(3,6,1)).toBe(20);
    expect(estimateWaitMinutes(3,6,0)).toBe(20);
    expect(estimateWaitMinutes(1,5,0)).toBe(5);
    expect(estimateWaitMinutes(1,5,5)).toBe(10);
    expect(estimateWaitMinutes(0,5,1)).toBe(5);
  });
  it('handles zero, negative and invalid values predictably',()=>{
    expect(estimateWaitMinutes(0,0,0)).toBe(0);
    expect(estimateWaitMinutes(-3,6,-10)).toBe(0);
    expect(estimateWaitMinutes(Number.NaN,Number.NaN,Number.NaN)).toBe(0);
  });
  it('uses the last 10 completed service records and falls back to department sample average',()=>{
    const queue=Array.from({length:12},(_,i)=>completed(String(i),i+1,new Date(Date.UTC(2026,0,1,0,i)).toISOString()));
    expect(averageServiceMinutes('general',queue,6)).toBe(8); // latest 10: 3..12, mean 7.5, rounded up
    expect(averageServiceMinutes('children',queue,8)).toBe(8);
  });
});
