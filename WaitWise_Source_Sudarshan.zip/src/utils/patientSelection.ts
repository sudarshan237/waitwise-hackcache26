import type { QueueEntry } from '../state/queueMachine';

/** A generic /patient visit must ask for a token; never silently restore a prior patient's token. */
export function selectTokenForRoute(token: string | null | undefined, queue: readonly QueueEntry[]): QueueEntry | undefined {
  const normalized = token?.trim().toLowerCase();
  if (!normalized) return undefined;
  return queue.find((entry) => entry.token.toLowerCase() === normalized);
}

/** Only attach an urgent flag to the patient explicitly open on the patient route. */
export function tokenForUrgentRequest(pathname: string, search: string, queue: readonly QueueEntry[]): string {
  if (pathname !== '/patient') return 'NO-TOKEN';
  const token = new URLSearchParams(search).get('token');
  return selectTokenForRoute(token, queue)?.token ?? 'NO-TOKEN';
}
