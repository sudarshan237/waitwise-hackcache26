export interface TokenAllocation {
  token: string;
  nextNumber: number;
}

/** Allocate the next unused simulated token. A stale counter cannot reuse an existing token. */
export function allocateToken(prefix: string, startNumber: number | undefined, existingTokens: Iterable<string>): TokenAllocation {
  const parsed = Number(startNumber);
  let number = Number.isInteger(parsed) && parsed >= 1 ? parsed : 101;
  const taken = new Set(Array.from(existingTokens, (token) => token.trim().toUpperCase()));
  let token = `${prefix}-${number}`.toUpperCase();
  while (taken.has(token)) {
    number += 1;
    token = `${prefix}-${number}`.toUpperCase();
  }
  return { token, nextNumber: number + 1 };
}
