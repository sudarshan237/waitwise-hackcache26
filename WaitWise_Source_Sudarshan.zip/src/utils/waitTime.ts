import { getDepartment, type DepartmentId } from '../data/departments';
import type { QueueEntry } from '../state/queueMachine';
import { DEPARTMENTS, type Department } from '../data/departments';

export interface DoctorState { status: 'available' | 'break' | 'late'; delayMinutes: number; }

export function estimateWaitMinutes(ahead: number, averageServiceMinutes: number, doctorDelayMinutes = 0): number {
  const people = Number.isFinite(ahead) ? Math.max(0, ahead) : 0;
  const service = Number.isFinite(averageServiceMinutes) ? Math.max(0, averageServiceMinutes) : 0;
  const delay = Number.isFinite(doctorDelayMinutes) ? Math.max(0, doctorDelayMinutes) : 0;
  const raw = people * service + delay;
  return raw === 0 ? 0 : Math.ceil(raw / 5) * 5;
}

export function entryWait(entry: QueueEntry, ahead: number, doctors: Partial<Record<DepartmentId, DoctorState>>, queue: QueueEntry[] = []): number {
  if (entry.status !== 'waiting') return 0;
  const dept = getDepartment(entry.department);
  const doctor = doctors[entry.department] ?? { status: 'available', delayMinutes: 0 };
  const delay = doctor.status === 'available' ? 0 : Math.max(0, doctor.delayMinutes);
  return estimateWaitMinutes(ahead, averageServiceMinutes(entry.department, queue, dept.serviceMinutes), delay);
}

/** Mean of the most recent ten completed synthetic consultations; fallback to sample department timing. */
export function averageServiceMinutes(department: DepartmentId, queue: QueueEntry[], fallback?: number): number {
  const completed = queue
    .filter((entry) => entry.department === department && entry.status === 'completed' && Number.isFinite(entry.serviceMinutes) && (entry.serviceMinutes ?? 0) > 0)
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
    .slice(0, 10);
  if (!completed.length) return fallback ?? DEPARTMENTS.find((d) => d.id === department)?.serviceMinutes ?? 5;
  return Math.max(1, Math.ceil(completed.reduce((sum, entry) => sum + (entry.serviceMinutes ?? 0), 0) / completed.length));
}
